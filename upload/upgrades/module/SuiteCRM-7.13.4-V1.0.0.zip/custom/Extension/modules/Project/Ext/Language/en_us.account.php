<?php

$mod_strings['LBL_NAME_ACCOUNT'] = 'Account';
