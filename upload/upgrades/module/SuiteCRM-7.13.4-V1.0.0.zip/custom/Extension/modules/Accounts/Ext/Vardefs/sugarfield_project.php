<?php

$dictionary["Account"]["fields"]["account_projects"] = array (
    'name' => 'account_projects',
    'type' => 'link',
    'relationship' => 'account_projects_rel',
    'module' => 'Project',
    'bean_name' => 'Project',
    'source' => 'non-db',
    'vname' => 'LBL_ACCOUNT_PROJECTS',
);
